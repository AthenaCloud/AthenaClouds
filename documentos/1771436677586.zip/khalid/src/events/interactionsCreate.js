const { EmbedBuilder, MessageFlags, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const logger = require('../utils/logger');
require('dotenv')

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {

        // --- SISTEMINHA DE ALUGUEL BASICO ---
        const isOwner = interaction.user.id === process.env.OWNER_ID ;
        const isActivationCommand = ['activerent'].includes(interaction.commandName);

        if (!isOwner && !isActivationCommand && interaction.guild) {
            const rent = db.prepare('SELECT expires_at FROM guild_rent WHERE guild_id = ?').get(interaction.guild.id);
            
            if (!rent || Date.now() > rent.expires_at) {
                return interaction.reply({ 
                    content: '❌ Este servidor não possui um aluguel ativo. Entre em contato com o desenvolvedor.\n\n<@1363774930100949095>', 
                    flags: [MessageFlags.Ephemeral] 
                });
            }
        }
        
        // --- LÓGICA DE SLASH COMMANDS ---
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return;

            try {
                logger.info(`Comando /${interaction.commandName} usado por ${interaction.user.tag}`);
                await command.run(client, interaction);
            } catch (error) {
                logger.error(`Erro ao executar /${interaction.commandName}: ${error}`);
                const errorPayload = { 
                    content: '❌ Ocorreu um erro ao executar este comando!', 
                    flags: [MessageFlags.Ephemeral] 
                };
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(errorPayload).catch(() => {});
                } else {
                    await interaction.reply(errorPayload).catch(() => {});
                }
            }
        }

        // --- LÓGICA DE MODAIS ---
        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'announce_modal') {
                const title = interaction.fields.getTextInputValue('ann_title');
                const desc = interaction.fields.getTextInputValue('ann_desc');

                const embed = new EmbedBuilder()
                    .setTitle(title)
                    .setDescription(desc)
                    .setColor('Blue')
                    .setFooter({ text: `Anunciado por ${interaction.user.tag}` });

                await interaction.reply({ content: '✅ Anúncio enviado!', flags: [MessageFlags.Ephemeral] });
                await interaction.channel.send({ embeds: [embed] });
            }

            // Modal de Configuração de Logs aqui
            if (interaction.customId === 'config_modal') {
                const channelId = interaction.fields.getTextInputValue('log_channel_id');
                const channel = interaction.guild.channels.cache.get(channelId);

                if (!channel || channel.type !== ChannelType.GuildText) {
                    return interaction.reply({ 
                        content: '❌ ID Inválido! Insira o ID de um canal de texto deste servidor.', 
                        flags: [MessageFlags.Ephemeral] 
                    });
                }

                db.prepare(`
                    INSERT INTO config (guild_id, log_channel) 
                    VALUES (?, ?) 
                    ON CONFLICT(guild_id) DO UPDATE SET log_channel = ?
                `).run(interaction.guild.id, channelId, channelId);

                await interaction.reply({ 
                    content: `✅ Sucesso! O canal de logs foi definido para ${channel}.`, 
                    flags: [MessageFlags.Ephemeral] 
                });
            }

            // Modal de Boas-Vindas aqui
            if (interaction.customId.startsWith('welcome_modal_')) {
                const channelId = interaction.customId.replace('welcome_modal_', '');
                const welcomeMsg = interaction.fields.getTextInputValue('welcome_text');

                db.prepare(`
                    INSERT INTO config (guild_id, welcome_channel, welcome_msg) 
                    VALUES (?, ?, ?) 
                    ON CONFLICT(guild_id) DO UPDATE SET welcome_channel = ?, welcome_msg = ?
                `).run(interaction.guild.id, channelId, welcomeMsg, channelId, welcomeMsg);

                await interaction.reply({ 
                    content: `✅ **Boas-vindas configuradas!**\nA mensagem foi salva para o canal <#${channelId}>.`, 
                    flags: [MessageFlags.Ephemeral] 
                });
            }

            // LÓGICA DE REGRAS AQUI
            if (interaction.customId.startsWith('rl_')) {
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });

                try {
                    const channelId = interaction.customId.replace('rl_', '');
                    const rulesText = interaction.fields.getTextInputValue('rules_content');
                    const channel = await interaction.guild.channels.fetch(channelId).catch(() => null);

                    if (!channel) {
                        return interaction.editReply({ content: '❌ Canal não encontrado ou sem permissão.' });
                    }

                    const rulesEmbed = new EmbedBuilder()
                        .setTitle(`**📜 Regras do Servidor - ${interaction.guild.name}**`) 
                        .setDescription(rulesText.replace('{guild}', interaction.guild.name)) 
                        .setColor('LuminousVividPink')
                        .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                        .setTimestamp();

                    await channel.send({ embeds: [rulesEmbed] });
                    await interaction.editReply({ content: `✅ Regras enviadas com sucesso no canal ${channel}!` });

                } catch (error) {
                    logger.error(`Erro ao processar modal de regras: ${error}`);
                    await interaction.editReply({ content: '❌ Erro interno ao enviar as regras.' });
                }
            }
        }

        // --- LÓGICA DE SELECT MENU ---
        if (interaction.isStringSelectMenu()) {
            if (interaction.customId === 'help_menu') {
                const category = interaction.values[0];
                const commands = client.commands.filter(c => c.category === category);
                
                const helpEmbed = new EmbedBuilder()
                    .setTitle(`📂 Categoria: ${category.charAt(0).toUpperCase() + category.slice(1)}`)
                    .setColor('Green')
                    .setTimestamp();

                if (commands.size === 0) {
                    helpEmbed.setDescription('Nenhum comando encontrado nesta categoria.');
                } else {
                    const list = commands.map(c => `**/${c.name}**\n└ ${c.description}`).join('\n\n');
                    helpEmbed.setDescription(list);
                }

                await interaction.update({ embeds: [helpEmbed] });
            }

            if (interaction.customId === 'reaction_roles_menu') {
                await interaction.deferReply({ flags: [MessageFlags.Ephemeral] });
                const selectedRoles = interaction.values; 
                const member = interaction.member;
                const allMenuRoles = ['ID_DO_CARGO_1', 'ID_DO_CARGO_2', 'ID_DO_CARGO_3']; 

                try {
                    for (const roleId of allMenuRoles) {
                        const hasRole = member.roles.cache.has(roleId);
                        const shouldHave = selectedRoles.includes(roleId);
                        if (shouldHave && !hasRole) await member.roles.add(roleId);
                        else if (!shouldHave && hasRole) await member.roles.remove(roleId);
                    }
                    await interaction.editReply({ content: '✅ Seus cargos foram atualizados com sucesso!' });
                } catch (error) {
                    logger.error(`Erro ao atribuir cargos: ${error}`);
                    await interaction.editReply({ content: '❌ Erro ao atualizar cargos. Verifique as minhas permissões!' });
                }
            }
        }

        // --- LÓGICA DE BOTÕES (TICKETS) ---
        if (interaction.isButton()) {
            const config = db.prepare('SELECT ticket_category, ticket_roles FROM config WHERE guild_id = ?').get(interaction.guild.id);

            // ABRIR TICKET
            if (interaction.customId === 'open_ticket') {
                const channelName = `ticket-${interaction.user.username}`;
                if (interaction.guild.channels.cache.find(c => c.name === channelName.toLowerCase())) {
                    return interaction.reply({ content: '❌ Você já tem um ticket.', flags: [MessageFlags.Ephemeral] });
                }

                const ticketChannel = await interaction.guild.channels.create({
                    name: channelName,
                    type: ChannelType.GuildText,
                    parent: config?.ticket_category,
                    permissionOverwrites: [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
                        { id: config?.ticket_roles, allow: [PermissionFlagsBits.ViewChannel], deny: [PermissionFlagsBits.SendMessages] }
                    ],
                });

                const embed = new EmbedBuilder()
                    .setTitle('🎫 Novo Ticket')
                    .setDescription(`Olá ${interaction.user}, aguarde um membro da equipe.\n\n**Staff:** Clique no botão abaixo para assumir este atendimento.`)
                    .setColor('Blue');

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('claim_ticket').setLabel('Assumir Ticket').setEmoji('🙋‍♂️').setStyle(ButtonStyle.Success),
                    new ButtonBuilder().setCustomId('close_ticket').setLabel('Fechar').setStyle(ButtonStyle.Danger)
                );

                await ticketChannel.send({ 
                    content: config?.ticket_roles ? `<@&${config.ticket_roles}>` : 'Staff', 
                    embeds: [embed], 
                    components: [row] 
                });
                await interaction.reply({ content: `✅ Ticket criado: ${ticketChannel}`, flags: [MessageFlags.Ephemeral] });
            }

            // ASSUMIR TICKET
            if (interaction.customId === 'claim_ticket') {
                if (!interaction.member.roles.cache.has(config?.ticket_roles)) {
                    return interaction.reply({ content: '❌ Apenas a equipe de suporte pode assumir tickets.', flags: [MessageFlags.Ephemeral] });
                }

                await interaction.channel.permissionOverwrites.edit(interaction.user.id, {
                    SendMessages: true,
                    ViewChannel: true
                });

                const embedClaim = new EmbedBuilder()
                    .setDescription(`👋 O staff ${interaction.user} assumiu este ticket e agora pode enviar mensagens.`)
                    .setColor('Green');

                const disabledRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('close_ticket').setLabel('Fechar').setStyle(ButtonStyle.Danger)
                );

                await interaction.update({ components: [disabledRow] });
                await interaction.channel.send({ embeds: [embedClaim] });
            }

            // FECHAR TICKET
            if (interaction.customId === 'close_ticket') {
                await interaction.reply({ content: '🔒 Fechando em 5 segundos...' });
                setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
            }
        }
    }
};
const { EmbedBuilder } = require('discord.js');
const db = require('../database/db');

module.exports = {
    name: 'messageUpdate',
    async execute(oldMessage, newMessage, client) {
        if (oldMessage.author?.bot || !oldMessage.guild) return;
        if (oldMessage.content === newMessage.content) return;

        // Busca o canal de logs configurado no SQLite
        const config = db.prepare('SELECT log_channel FROM config WHERE guild_id = ?').get(oldMessage.guild.id);
        if (!config?.log_channel) return;

        const logChannel = oldMessage.guild.channels.cache.get(config.log_channel);
        if (!logChannel) return;

        const embed = new EmbedBuilder()
            .setTitle('📝 Mensagem Editada')
            .setURL(newMessage.url)
            .setColor('Yellow')
            .setAuthor({ name: oldMessage.author.tag, iconURL: oldMessage.author.displayAvatarURL() })
            .addFields(
                { name: '👤 Autor', value: `${oldMessage.author}`, inline: true },
                { name: '📍 Canal', value: `${oldMessage.channel}`, inline: true },
                { 
                    name: '⬅️ Antes', 
                    value: `\`\`\`${oldMessage.content.slice(0, 1000) || '[Sem conteúdo]'}\`\`\`` 
                },
                { 
                    name: '➡️ Depois', 
                    value: `\`\`\`${newMessage.content.slice(0, 1000) || '[Sem conteúdo]'}\`\`\`` 
                }
            )
            .setFooter({ text: `ID do Usuário: ${oldMessage.author.id}` })
            .setTimestamp();

        try {
            await logChannel.send({ embeds: [embed] });
        } catch (err) {
            console.error(`Erro ao enviar log de edição: ${err.message}`);
        }
    }
};
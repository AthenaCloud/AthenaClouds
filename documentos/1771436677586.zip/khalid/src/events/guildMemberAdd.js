const db = require('../database/db');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member) {

        const config = db.prepare('SELECT welcome_channel, welcome_msg, autorole_id FROM config WHERE guild_id = ?').get(member.guild.id);
        if (!config) return;

        if (config.autorole_id) {
            const role = member.guild.roles.cache.get(config.autorole_id);
            if (role) member.roles.add(role).catch(() => {});
        }

        if (config.welcome_channel) {
            const channel = member.guild.channels.cache.get(config.welcome_channel);
            if (channel) {

                let rawMsg = config.welcome_msg || "Bem-vindo {user} ao servidor {guild}!";
                
                let finalMsg = rawMsg
                    .replace(/{user}/g, `${member}`)
                    .replace(/{guild}/g, `${member.guild.name}`);

                const embed = new EmbedBuilder()
                    .setTitle('👋 Nova Chegada!')
                    .setDescription(finalMsg)
                    .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
                    .addFields({ name: 'Contagem', value: `Agora somos **${member.guild.memberCount}** membros!` })
                    .setColor('Green')
                    .setTimestamp();

                channel.send({ embeds: [embed] });
            }
        }
    }
};
const { EmbedBuilder } = require('discord.js');
const db = require('../database/db');

module.exports = {
    name: 'messageDelete',
    async execute(message, client) {
        if (message.author?.bot || !message.guild) return;

        const config = db.prepare('SELECT log_channel FROM config WHERE guild_id = ?').get(message.guild.id);
        if (!config?.log_channel) return;

        const channel = message.guild.channels.cache.get(config.log_channel);
        if (!channel) return;

        const embed = new EmbedBuilder()
            .setTitle('🗑️ Mensagem Deletada')
            .setColor('Red')
            .addFields(
                { name: 'Autor', value: `${message.author.tag}`, inline: true },
                { name: 'Canal', value: `${message.channel}`, inline: true },
                { name: 'Conteúdo', value: `\`\`\`${message.content || '[Sem texto/Imagem]'}\`\`\`` }
            )
            .setTimestamp();

        channel.send({ embeds: [embed] });
    }
};
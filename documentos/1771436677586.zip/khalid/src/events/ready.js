const { ActivityType, PresenceUpdateStatus } = require("discord.js");

module.exports = {
    name: "ready",
    once: true,
    execute: async (client) => {
        const textList = [
            '🌟 Entre Agora!', 
            '🤖 Feito Por Tavares Coder',
            '💖 @AxiomBot',
            '🪐 Server na Bio'
        ];

        client.user.setPresence({ 
            activities: [{ name: 'Iniciando...', type: ActivityType.Watching }],
            status: 'dnd' 
        });

        setInterval(() => {
            const text = textList[Math.floor(Math.random() * textList.length)];
            
            client.user.setPresence({
                activities: [{ name: text, type: ActivityType.Watching }],
                status: 'dnd'
            });
        }, 3000);

        console.log(`\n==========================================`);
        console.log(`🌟 ${client.user.username} está online.`);
        console.log(`🏰 Servidores: ${client.guilds.cache.size}`);
        console.log(`👥 Estou interagindo com ${client.users.cache.size} usuarios simultâneo`)
        console.log(`==========================================\n`);
    }
};
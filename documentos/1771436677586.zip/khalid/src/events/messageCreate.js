const db = require('../database/db');

module.exports = {
    name: 'messageCreate',
    async execute(message) {
        if (message.author.bot || !message.guild) return;

        const userId = message.author.id;
        const xpGain = Math.floor(Math.random() * 10) + 5;

        let user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);

        if (!user) {
            db.prepare('INSERT INTO users (id, xp, level) VALUES (?, ?, ?)').run(userId, xpGain, 1);
        } else {
            let newXp = user.xp + xpGain;
            let nextLevelXp = user.level * 500;

            if (newXp >= nextLevelXp) {
                user.level++;
                newXp = 0;
                message.reply(`🆙 **Parabéns!** Você subiu para o **Nível ${user.level}**!`);
            }

            db.prepare('UPDATE users SET xp = ?, level = ? WHERE id = ?').run(newXp, user.level, userId);
        }
    }
};
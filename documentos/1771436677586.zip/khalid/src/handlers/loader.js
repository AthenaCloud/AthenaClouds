const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

module.exports = (client) => {
    const eventPath = path.join(__dirname, '../events');
    const eventFiles = fs.readdirSync(eventPath).filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        const event = require(`${eventPath}/${file}`);
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
    }

    const cmdFolderPath = path.join(__dirname, '../commands');
    const cmdFolders = fs.readdirSync(cmdFolderPath);

    for (const folder of cmdFolders) {
        const commandFiles = fs.readdirSync(`${cmdFolderPath}/${folder}`).filter(file => file.endsWith('.js'));
        for (const file of commandFiles) {
            const command = require(`${cmdFolderPath}/${folder}/${file}`);
            if (command.name) {
                command.category = folder.toLowerCase(); 
                client.commands.set(command.name, command);
            } else {
                logger.warn(`Arquivo ignorado: ${file} (falta propriedade "name")`);
            }
        }
    }
    logger.success('Sistemas carregados na memória com sucesso!');
};
const colors = require('colors');
const fs = require('fs');
const moment = require('moment');

const log = (message, type = 'info') => {
    const timestamp = `[${moment().format('DD/MM/YYYY HH:mm:ss')}]`;
    const logMessage = `${timestamp} [${type.toUpperCase()}] ${message}`;
    
    const colorMap = { info: 'blue', warn: 'yellow', error: 'red', success: 'green' };
    console.log(colors[colorMap[type] || 'white'](logMessage));

    fs.appendFileSync('bot_logs.txt', logMessage + '\n');
};

module.exports = {
    info: (msg) => log(msg, 'info'),
    warn: (msg) => log(msg, 'warn'),
    error: (msg) => log(msg, 'error'),
    success: (msg) => log(msg, 'success')
};
const fs = require('fs');
const path = require('path');

async function createTranscript(channel, member) {
    const messages = await channel.messages.fetch({ limit: 100 });
    let transcript = `Relatório de Ticket - Canal: #${channel.name}\n`;
    transcript += `Dono do Ticket: ${member.user.tag} (${member.id})\n`;
    transcript += `--------------------------------------------------\n\n`;

    messages.reverse().forEach(msg => {
        transcript += `[${msg.createdAt.toLocaleString()}] ${msg.author.tag}: ${msg.content}\n`;
    });

    const fileName = `transcript-${channel.id}.txt`;
    const filePath = path.join(__dirname, `../../transcripts/${fileName}`);

    if (!fs.existsSync(path.join(__dirname, '../../transcripts'))) {
        fs.mkdirSync(path.join(__dirname, '../../transcripts'));
    }

    fs.writeFileSync(filePath, transcript);
    return filePath;
}

module.exports = { createTranscript };
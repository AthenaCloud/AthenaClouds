const Database = require('better-sqlite3');
const db = new Database('database.sqlite');

// Criar Tabelas Iniciais
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, 
    xp INTEGER DEFAULT 0, 
    level INTEGER DEFAULT 1, 
    money INTEGER DEFAULT 0, 
    daily_last INTEGER DEFAULT 0,
    work_last INTEGER DEFAULT 0
  );
  
  CREATE TABLE IF NOT EXISTS warns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    guild_id TEXT,
    reason TEXT,
    admin_id TEXT,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tickets (
    channel_id TEXT PRIMARY KEY,
    owner_id TEXT,
    status TEXT DEFAULT 'open'
  );

  CREATE TABLE IF NOT EXISTS config (
    guild_id TEXT PRIMARY KEY,
    welcome_channel TEXT,
    welcome_msg TEXT,
    log_channel TEXT,
    ticket_category TEXT,
    ticket_roles TEXT,
    autorole_id TEXT
  );

  CREATE TABLE IF NOT EXISTS keys (
    key TEXT PRIMARY KEY,
    duration_ms INTEGER,
    used INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS guild_rent (
    guild_id TEXT PRIMARY KEY,
    expires_at INTEGER
  );
`);

/**
 * SISTEMA DE MIGRAÇÃO AUTOMÁTICA
 * Adiciona colunas novas a tabelas já existentes para evitar o erro "no such column".
 */
const migrations = [
    { table: 'users', column: 'work_last', type: 'INTEGER DEFAULT 0' },
    { table: 'users', column: 'daily_last', type: 'INTEGER DEFAULT 0' },
    { table: 'users', column: 'wallet', type: 'INTEGER DEFAULT 0' },
    { table: 'users', column: 'bank', type: 'INTEGER DEFAULT 0' },
    { table: 'users', column: 'guild_id', type: 'TEXT' },
    { table: 'config', column: 'welcome_msg', type: 'TEXT' },
    { table: 'config', column: 'log_channel', type: 'TEXT' },
    { table: 'config', column: 'ticket_category', type: 'TEXT' },
    { table: 'config', column: 'ticket_roles', type: 'TEXT' },
    { table: 'config', column: 'rent_expires', type: 'INTEGER DEFAULT 0' }
];

migrations.forEach(m => {
    try {
        db.exec(`ALTER TABLE ${m.table} ADD COLUMN ${m.column} ${m.type};`);
    } catch (e) {
    }
});

module.exports = db;
const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
} = require('discord.js');

module.exports = {
    name: 'help',
    description: 'Lista os comandos do bot por categoria',
    run: async (client, interaction) => {
        const embed = new EmbedBuilder()
            .setTitle('🤖 Central de Ajuda')
            .setDescription('Olá! Sou o **Khalid Bot**. Use o menu abaixo para navegar entre as categorias de comandos.')
            .setColor('Blue')
            .setThumbnail(client.user.displayAvatarURL())
            .addFields(
                { name: '✨ Dica', value: 'Selecione uma opção abaixo para ver os detalhes.' }
            );

        const row = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('help_menu')
                .setPlaceholder('Selecione uma categoria...')
                .addOptions([
                    { label: 'Administração', description: 'Configurações do servidor', value: 'admin', emoji: '⚙️' },
                    { label: 'Moderação', description: 'Ferramentas de punição e limpeza', value: 'moderation', emoji: '🛡️' },
                    { label: 'Economia', description: 'Sistema de moedas e ranking', value: 'economy', emoji: '💰' },
                    { label: 'Geral', description: 'Comandos informativos e úteis', value: 'general', emoji: '🌍' }
                ])
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};
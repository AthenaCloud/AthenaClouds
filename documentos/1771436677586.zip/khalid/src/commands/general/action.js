const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');

module.exports = {
    name: 'action',
    description: 'Interaja com outros usuários',
    options: [
        {
            name: 'tipo',
            type: ApplicationCommandOptionType.String,
            description: 'Tipo de ação',
            required: true,
            choices: [
                { name: 'Abraçar (Hug)', value: 'abraçou' },
                { name: 'Beijar (Kiss)', value: 'beijou' },
                { name: 'Tapa (Slap)', value: 'deu um tapa em' }
            ]
        },
        {
            name: 'usuario',
            type: ApplicationCommandOptionType.User,
            description: 'Usuário alvo',
            required: true
        }
    ],
    run: async (client, interaction) => {
        const action = interaction.options.getString('tipo');
        const target = interaction.options.getUser('usuario');
        
        const gifs = {
            'abraçou': 'https://i.giphy.com/media/v1.Y2lkPTc5MGI3NjExNHJndnZpYmt4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/lrrSRWAApToMk/giphy.gif',
            'beijou': 'https://i.giphy.com/media/v1.Y2lkPTc5MGI3NjExNHJndnZpYmt4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/bm2O3nXTcK3tK/giphy.gif',
            'deu um tapa em': 'https://i.giphy.com/media/v1.Y2lkPTc5MGI3NjExNHJndnZpYmt4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4bmZ4JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/u8feADL7LSAb6/giphy.gif'
        };

        const embed = new EmbedBuilder()
            .setColor('LuminousVividPink')
            .setDescription(`💖 **${interaction.user.username}** ${action} **${target.username}**!`)
            .setImage(gifs[action]);

        await interaction.reply({ content: `${target}`, embeds: [embed] });
    }
};
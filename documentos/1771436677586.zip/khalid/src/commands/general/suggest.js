const { EmbedBuilder, ApplicationCommandOptionType, MessageFlags } = require('discord.js');

module.exports = {
    name: 'suggest',
    description: 'Envie uma sugestão para o servidor',
    options: [{
        name: 'sugestao',
        type: ApplicationCommandOptionType.String,
        description: 'Descreva sua ideia detalhadamente',
        required: true
    }],
    run: async (client, interaction) => {
        const text = interaction.options.getString('sugestao');

        const embed = new EmbedBuilder()
            .setTitle('💡 Nova Sugestão')
            .setColor('Purple')
            .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
            .setDescription(text)
            .addFields(
                { name: '📊 Status', value: 'Em votação aguardando feedback.' }
            )
            .setFooter({ text: 'Vote usando as reações abaixo!' })
            .setTimestamp();

        const msg = await interaction.reply({ 
            content: '✅ Sua sugestão foi postada!', 
            embeds: [embed], 
            fetchReply: true 
        });

        await msg.react('👍');
        await msg.react('👎');
    }
};
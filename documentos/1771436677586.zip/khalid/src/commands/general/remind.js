const { ApplicationCommandOptionType, EmbedBuilder, MessageFlags } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'remind',
    description: 'Define um lembrete para o futuro',
    options: [
        { name: 'tempo', type: ApplicationCommandOptionType.String, description: 'Ex: 10m, 1h, 1d', required: true },
        { name: 'mensagem', type: ApplicationCommandOptionType.String, description: 'O que devo te lembrar?', required: true }
    ],
    run: async (client, interaction) => {
        const time = interaction.options.getString('tempo');
        const message = interaction.options.getString('mensagem');
        const msTime = ms(time);

        if (!msTime) return interaction.reply({ content: '❌ Formato de tempo inválido! Use: 10m, 2h, etc.', flags: [MessageFlags.Ephemeral] });

        await interaction.reply({ content: `✅ Entendido! Vou te lembrar de: **${message}** em **${time}**.` });

        setTimeout(async () => {
            try {
                const embed = new EmbedBuilder()
                    .setTitle('🔔 Lembrete!')
                    .setDescription(`Você pediu para eu te lembrar de: **${message}**`)
                    .setColor('Yellow')
                    .setTimestamp();
                
                await interaction.user.send({ embeds: [embed] }).catch(() => {
                    interaction.channel.send({ content: `🔔 ${interaction.user}, seu lembrete: **${message}**` });
                });
            } catch (err) {
                console.log("Erro ao enviar lembrete.");
            }
        }, msTime);
    }
};
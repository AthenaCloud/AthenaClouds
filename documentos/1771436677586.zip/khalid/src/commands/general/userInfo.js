const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');
const moment = require('moment');

module.exports = {
    name: 'userinfo',
    description: 'Exibe informações de um usuário',
    options: [{
        name: 'target',
        type: ApplicationCommandOptionType.User,
        description: 'Usuário para ver info',
        required: false
    }],
    run: async (client, interaction) => {
        const user = interaction.options.getUser('target') || interaction.user;
        const member = await interaction.guild.members.fetch(user.id);

        const embed = new EmbedBuilder()
            .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL() })
            .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 1024 }))
            .setColor('Random')
            .addFields(
                { name: '🆔 ID', value: `\`${user.id}\``, inline: true },
                { name: '📅 Conta Criada', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
                { name: '📥 Entrada no Servidor', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
                { name: '🎭 Cargos', value: member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => r).join(' ') || 'Nenhum' }
            );

        await interaction.reply({ embeds: [embed] });
    }
};
const { ApplicationCommandOptionType, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'avatar',
    description: 'Mostra o avatar de um usuário em alta resolução',
    options: [{
        name: 'usuario',
        type: ApplicationCommandOptionType.User,
        description: 'Selecione o usuário',
        required: false
    }],
    run: async (client, interaction) => {
        const user = interaction.options.getUser('usuario') || interaction.user;
        const png = user.displayAvatarURL({ extension: 'png', size: 2048 });
        const jpg = user.displayAvatarURL({ extension: 'jpg', size: 2048 });
        const webp = user.displayAvatarURL({ extension: 'webp', size: 2048 });

        const embed = new EmbedBuilder()
            .setTitle(`🖼️ Avatar de ${user.username}`)
            .setImage(user.displayAvatarURL({ size: 1024, dynamic: true }))
            .setColor('Random');

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setLabel('PNG').setURL(png).setStyle(ButtonStyle.Link),
            new ButtonBuilder().setLabel('JPG').setURL(jpg).setStyle(ButtonStyle.Link),
            new ButtonBuilder().setLabel('WEBP').setURL(webp).setStyle(ButtonStyle.Link)
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};
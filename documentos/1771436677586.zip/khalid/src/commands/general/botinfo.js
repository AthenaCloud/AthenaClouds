const { ApplicationCommandType, EmbedBuilder, version } = require('discord.js');
const os = require('os');

module.exports = {
  name: "botinfo",
  description: "[📊] Exibe informações e estatísticas do bot.",
  type: ApplicationCommandType.ChatInput,
  
  run: async (client, interaction) => {

    let totalSeconds = (client.uptime / 1000);
    let days = Math.floor(totalSeconds / 86400);
    totalSeconds %= 86400;
    let hours = Math.floor(totalSeconds / 3600);
    totalSeconds %= 3600;
    let minutes = Math.floor(totalSeconds / 60);
    let seconds = Math.floor(totalSeconds % 60);
    const uptime = `${days}d, ${hours}h, ${minutes}m, ${seconds}s`;

    const memoryUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    
    const embed = new EmbedBuilder()
        .setColor(0x00CED1)
        .setTitle(`📊 Estatísticas de ${client.user.username}`)
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 256 }))
        .addFields(
            { name: '👑 Desenvolvedor', value: `<@1363774930100949095>`, inline: true },
            { name: '⏳ Tempo Online', value: uptime, inline: true },
            { name: '💻 Memória (RAM)', value: `${memoryUsage} MB`, inline: true },
            { name: '🌐 Servidores', value: `${client.guilds.cache.size}`, inline: true },
            { name: '👥 Usuários', value: `${client.users.cache.size}`, inline: true },
            { name: '⚙️ Versão Discord.js', value: `v${version}`, inline: true },
            { name: '🚀 Plataforma', value: `${os.platform()} (${os.arch()})`, inline: true }
        )
        .setFooter({ text: `ID: ${client.user.id}` });

    await interaction.reply({ embeds: [embed] });
  }
};
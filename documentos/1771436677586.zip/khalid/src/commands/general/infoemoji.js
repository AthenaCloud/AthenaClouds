const { 
    ApplicationCommandOptionType, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'infoemoji',
    description: 'Exibe informações detalhadas do emoji escolhido',
    options: [
        {
            name: 'emoji',
            type: ApplicationCommandOptionType.String,
            description: 'Insira o emoji que você deseja consultar',
            required: true
        }
    ],
    run: async (client, interaction) => {
        // 1. Responder imediatamente para evitar o erro "Unknown interaction"
        await interaction.deferReply();

        try {
            const emojiInput = interaction.options.getString('emoji');
            
            // Regex para capturar ID e Nome de emojis customizados
            const emojiData = emojiInput.match(/<?(?:a:)?([^:]+):(\d{17,19})>?/);

            if (!emojiData) {
                return interaction.editReply({ 
                    content: '❌ Por favor, insira um emoji customizado válido.'
                });
            }

            const [full, name, id] = emojiData;
            const isAnimated = emojiInput.includes('<a:');
            const extension = isAnimated ? 'gif' : 'png';
            const emojiUrl = `https://cdn.discordapp.com/emojis/${id}.${extension}`;

            // Tenta encontrar o emoji no cache ou calcula a data a partir do ID
            const emojiObject = client.emojis.cache.get(id);
            const createdAt = emojiObject ? emojiObject.createdTimestamp : (Number(id) / 4194304) + 1420070400000;
            const timestamp = Math.floor(createdAt / 1000);

            const embed = new EmbedBuilder()
                .setAuthor({ 
                    name: 'Sobre o emoji', 
                    iconURL: 'https://cdn-icons-png.flaticon.com/512/25/25231.png' 
                })
                .setColor('#5865F2')
                .setThumbnail(emojiUrl)
                .addFields(
                    { name: '📑 Nome do emoji', value: `\`${name}\``, inline: true },
                    { name: '💻 ID do emoji', value: `\`${id}\``, inline: true },
                    { name: '👀 Menção', value: `\`<:${full}\``, inline: true },
                    { name: '📅 Criado em', value: `<t:${timestamp}:F> (<t:${timestamp}:R>)`, inline: false }
                );

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setLabel('Abrir emoji no navegador')
                    .setURL(emojiUrl)
                    .setStyle(ButtonStyle.Link)
            );

            await interaction.editReply({ embeds: [embed], components: [row] });

        } catch (error) {
            console.error(error);
            if (interaction.deferred) {
                await interaction.editReply({ content: '❌ Ocorreu um erro ao processar o emoji.' });
            }
        }
    }
};
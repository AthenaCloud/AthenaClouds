const { ApplicationCommandOptionType, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'giveaway',
    description: 'Inicia um sorteio rápido no canal',
    options: [
        { name: 'premio', type: ApplicationCommandOptionType.String, description: 'O que será sorteado?', required: true },
        { name: 'vencedores', type: ApplicationCommandOptionType.Integer, description: 'Número de ganhadores', required: true }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return interaction.reply({ content: '❌ Você não tem permissão para gerenciar sorteios.', ephemeral: true });
        }

        const prize = interaction.options.getString('premio');
        const winnerCount = interaction.options.getInteger('vencedores');

        const embed = new EmbedBuilder()
            .setTitle('🎉 NOVO SORTEIO!')
            .setDescription(`Prêmio: **${prize}**\nClique em 🎉 para participar!\n\n**Sorteado por:** ${interaction.user}`)
            .setFooter({ text: 'O sorteio termina em 30 segundos!' })
            .setColor('DarkVividPink')
            .setTimestamp();

        const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
        await msg.react('🎉');

        const filter = (reaction, user) => reaction.emoji.name === '🎉' && !user.bot;
        const collector = msg.createReactionCollector({ filter, time: 30000 });

        collector.on('end', async (collected) => {
            const reaction = collected.first();
            if (!reaction) return interaction.channel.send('❌ O sorteio terminou e ninguém reagiu.');

            const users = await reaction.users.fetch();
            const participants = users.filter(u => !u.bot);

            if (participants.size === 0) return interaction.channel.send('❌ Ninguém participou do sorteio.');

            const winners = participants.random(Math.min(participants.size, winnerCount));
            interaction.channel.send(`🎉 Parabéns ${winners.join(', ')}! Você(s) ganhou(aram): **${prize}**`);
        });
    }
};
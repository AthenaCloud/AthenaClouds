const { ApplicationCommandOptionType, MessageFlags } = require('discord.js');
const db = require('../../database/db');

module.exports = {
    name: 'activerent',
    description: 'Ativa o aluguel do servidor usando uma key',
    options: [
        {
            name: 'key',
            type: ApplicationCommandOptionType.String,
            description: 'Insira sua chave de ativação',
            required: true
        }
    ],
    run: async (client, interaction) => {
        const keyInput = interaction.options.getString('key');
        const keyData = db.prepare('SELECT * FROM keys WHERE key = ? AND used = 0').get(keyInput);

        if (!keyData) {
            return interaction.reply({ content: '❌ Key inválida ou já utilizada.', flags: [MessageFlags.Ephemeral] });
        }

        const now = Date.now();
        const newExpiration = now + keyData.duration_ms;

        db.prepare('UPDATE keys SET used = 1 WHERE key = ?').run(keyInput);
        db.prepare(`
            INSERT INTO guild_rent (guild_id, expires_at) 
            VALUES (?, ?) 
            ON CONFLICT(guild_id) DO UPDATE SET expires_at = expires_at + ?
        `).run(interaction.guild.id, newExpiration, keyData.duration_ms);

        await interaction.reply({
            content: `✅ **Aluguel Ativado!**\nO servidor agora tem acesso às funcionalidades até <t:${Math.floor(newExpiration / 1000)}:F>.`,
        });
    }
};
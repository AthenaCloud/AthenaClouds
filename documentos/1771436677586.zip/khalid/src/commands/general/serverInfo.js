const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'serverinfo',
    description: 'Exibe informações detalhadas do servidor',
    run: async (client, interaction) => {
        const { guild } = interaction;
        const { members, channels, emojis, roles } = guild;

        const embed = new EmbedBuilder()
            .setTitle(`📊 Informações de ${guild.name}`)
            .setThumbnail(guild.iconURL({ dynamic: true }))
            .setColor('Blurple')
            .addFields(
                { name: '👑 Dono', value: `<@${guild.ownerId}>`, inline: true },
                { name: '📅 Criado em', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
                { name: '👥 Membros', value: `Total: ${guild.memberCount}`, inline: true },
                { name: '💬 Canais', value: `Texto: ${channels.cache.filter(c => c.type === 0).size}\nVoz: ${channels.cache.filter(c => c.type === 2).size}`, inline: true },
                { name: '🛡️ Verificação', value: `${guild.verificationLevel}`, inline: true },
                { name: '🚀 Impulsos', value: `${guild.premiumSubscriptionCount || 0} Nível: ${guild.premiumTier}`, inline: true }
            )
            .setFooter({ text: `ID do Servidor: ${guild.id}` });

        await interaction.reply({ embeds: [embed] });
    }
};
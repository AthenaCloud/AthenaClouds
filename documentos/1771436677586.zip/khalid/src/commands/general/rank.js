const { AttachmentBuilder, ApplicationCommandOptionType } = require('discord.js');
const Canvas = require('canvas');
const db = require('../../database/db');

module.exports = {
    name: 'rank',
    description: 'Veja seu nível com um card visual',
    options: [{ 
        name: 'usuario', 
        type: ApplicationCommandOptionType.User, 
        description: 'Selecione um usuário para ver o rank', 
        required: false 
    }],
    run: async (client, interaction) => {
        await interaction.deferReply(); 

        const target = interaction.options.getUser('usuario') || interaction.user;
        const data = db.prepare('SELECT xp, level FROM users WHERE id = ?').get(target.id);

        if (!data) return interaction.editReply('❌ Usuário sem registros no banco de dados.');

        const nextLevelXp = data.level * 500;
        const progress = Math.min(data.xp / nextLevelXp, 1); 

        const canvas = Canvas.createCanvas(700, 250);
        const ctx = canvas.getContext('2d');

        ctx.fillStyle = '#23272A';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = '#484B4E';
        ctx.beginPath();
        ctx.roundRect(200, 160, 450, 30, 15);
        ctx.fill();

        ctx.fillStyle = '#5865F2';
        ctx.beginPath();
        ctx.roundRect(200, 160, 450 * progress, 30, 15);
        ctx.fill();

        ctx.font = 'bold 32px sans-serif';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(target.username, 210, 80);

        ctx.font = '24px sans-serif';
        ctx.fillStyle = '#B9BBBE';
        ctx.fillText(`Nível ${data.level}`, 210, 120);
        ctx.fillText(`${data.xp} / ${nextLevelXp} XP`, 500, 150);

        ctx.save();
        ctx.beginPath();
        ctx.arc(100, 125, 75, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();

        const avatar = await Canvas.loadImage(target.displayAvatarURL({ extension: 'png', size: 256 }));
        ctx.drawImage(avatar, 25, 50, 150, 150);
        ctx.restore();

        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'rank.png' });
        await interaction.editReply({ files: [attachment] });
    }
};
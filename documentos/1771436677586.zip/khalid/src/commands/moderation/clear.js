const { ApplicationCommandOptionType, PermissionFlagsBits, MessageFlags } = require('discord.js');

module.exports = {
    name: 'clear',
    description: 'Limpa mensagens de um canal',
    options: [{
        name: 'quantidade',
        type: ApplicationCommandOptionType.Integer,
        description: 'Número de mensagens (1-100)',
        required: true
    }],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return interaction.reply({ content: '❌ Permissão insuficiente.', flags: [MessageFlags.Ephemeral] });
        }

        const amount = interaction.options.getInteger('quantidade');
        if (amount < 1 || amount > 100) return interaction.reply({ content: '❌ Escolha entre 1 e 100.', flags: [MessageFlags.Ephemeral] });

        const deleted = await interaction.channel.bulkDelete(amount, true);
        
        await interaction.reply({ 
            content: `🧹 Limpeza concluída! **${deleted.size}** mensagens removidas.`, 
            flags: [MessageFlags.Ephemeral] 
        });
    }
};
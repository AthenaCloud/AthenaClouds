const { ApplicationCommandOptionType, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');

module.exports = {
    name: 'kick',
    description: 'Expulsa um membro do servidor',
    options: [
        { name: 'usuario', type: ApplicationCommandOptionType.User, description: 'Membro a expulsar', required: true },
        { name: 'motivo', type: ApplicationCommandOptionType.String, description: 'Motivo da expulsão', required: false }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return interaction.reply({ content: '❌ Sem permissão.', flags: [MessageFlags.Ephemeral] });
        }

        const target = interaction.options.getMember('usuario');
        const reason = interaction.options.getString('motivo') || 'Não especificado';

        if (!target) return interaction.reply({ content: '❌ Membro não encontrado.', flags: [MessageFlags.Ephemeral] });
        if (!target.kickable) return interaction.reply({ content: '❌ Não tenho permissão para expulsar este membro.', flags: [MessageFlags.Ephemeral] });

        await target.kick(reason);

        const embed = new EmbedBuilder()
            .setTitle('👢 Membro Expulso')
            .setColor('Orange')
            .addFields(
                { name: '👤 Membro', value: `${target.user.tag}`, inline: true },
                { name: '👮 Staff', value: `${interaction.user.tag}`, inline: true },
                { name: '📝 Motivo', value: reason }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};
const { ApplicationCommandOptionType, EmbedBuilder, MessageFlags } = require('discord.js');
const db = require('../../database/db');

module.exports = {
    name: 'warns',
    description: 'Verifica o histórico de avisos de um membro',
    options: [{
        name: 'usuario',
        type: ApplicationCommandOptionType.User,
        description: 'Membro para consultar',
        required: true
    }],
    run: async (client, interaction) => {
        const target = interaction.options.getUser('usuario');
        const warnings = db.prepare('SELECT * FROM warns WHERE user_id = ? AND guild_id = ?').all(target.id, interaction.guild.id);

        if (warnings.length === 0) {
            return interaction.reply({ content: `✅ **${target.tag}** não possui avisos registrados.`, flags: [MessageFlags.Ephemeral] });
        }

        const embed = new EmbedBuilder()
            .setTitle(`📜 Avisos de ${target.username}`)
            .setColor('Yellow')
            .setDescription(warnings.map((w, i) => `**#${i + 1}** | Razão: \`${w.reason}\`\nStaff: <@${w.admin_id}> | Data: <t:${Math.floor(new Date(w.date).getTime() / 1000)}:d>`).join('\n\n'))
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};
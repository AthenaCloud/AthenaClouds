const { ApplicationCommandOptionType, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');
const ms = require('ms');

module.exports = {
    name: 'mute',
    description: 'Silencia um membro temporariamente',
    options: [
        { name: 'usuario', type: ApplicationCommandOptionType.User, description: 'Membro a silenciar', required: true },
        { name: 'tempo', type: ApplicationCommandOptionType.String, description: 'Ex: 10m, 1h, 1d', required: true },
        { name: 'motivo', type: ApplicationCommandOptionType.String, description: 'Motivo do castigo', required: false }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            return interaction.reply({ content: '❌ Sem permissão.', flags: [MessageFlags.Ephemeral] });
        }

        const target = interaction.options.getMember('usuario');
        const duration = interaction.options.getString('tempo');
        const reason = interaction.options.getString('motivo') || 'Não especificado';

        const msTime = ms(duration);
        if (!msTime || msTime > 2419200000) { 
            return interaction.reply({ content: '❌ Tempo inválido! Usa: 10m, 1h, 7d.', flags: [MessageFlags.Ephemeral] });
        }

        if (!target.moderatable) return interaction.reply({ content: '❌ Não posso silenciar este membro.', flags: [MessageFlags.Ephemeral] });

        await target.timeout(msTime, reason);

        const embed = new EmbedBuilder()
            .setTitle('🔇 Membro Silenciado')
            .setColor('Grey')
            .addFields(
                { name: '👤 Membro', value: `${target}`, inline: true },
                { name: '🕒 Duração', value: `\`${duration}\``, inline: true },
                { name: '📝 Motivo', value: reason }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};
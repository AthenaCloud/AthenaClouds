const { ApplicationCommandOptionType, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');
const db = require('../../database/db');

module.exports = {
    name: 'warn',
    description: 'Aplica um aviso a um membro',
    options: [
        {
            name: 'usuario',
            type: ApplicationCommandOptionType.User,
            description: 'Usuário a ser advertido',
            required: true
        },
        {
            name: 'motivo',
            type: ApplicationCommandOptionType.String,
            description: 'Motivo do aviso',
            required: false
        }
    ],
    run: async (client, interaction) => {
        // Verificação de permissão
        if (!interaction.member.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            return interaction.reply({ 
                content: '❌ Você não tem permissão para usar este comando.', 
                flags: [MessageFlags.Ephemeral] 
            });
        }

        const target = interaction.options.getUser('usuario');
        const reason = interaction.options.getString('motivo') || 'Nenhum motivo fornecido';

        // Segurança: Evitar erro caso o usuário não seja encontrado
        if (!target) {
            return interaction.reply({ content: '❌ Usuário não encontrado.', flags: [MessageFlags.Ephemeral] });
        }

        try {
            // Salvar no SQLite
            const stmt = db.prepare('INSERT INTO warns (user_id, guild_id, reason, admin_id) VALUES (?, ?, ?, ?)');
            stmt.run(target.id, interaction.guild.id, reason, interaction.user.id);

            const embed = new EmbedBuilder()
                .setTitle('⚠️ Aviso Registrado')
                .setColor('Orange')
                .addFields(
                    { name: '👤 Usuário', value: `${target.tag} (${target.id})`, inline: true },
                    { name: '👮 Staff', value: `${interaction.user.tag}`, inline: true },
                    { name: '📝 Motivo', value: reason }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: '❌ Erro ao salvar o aviso no banco de dados.', flags: [MessageFlags.Ephemeral] });
        }
    }
};
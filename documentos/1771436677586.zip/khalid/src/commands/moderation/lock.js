const { ApplicationCommandOptionType, PermissionFlagsBits, MessageFlags } = require('discord.js');

module.exports = {
    name: 'lock',
    description: 'Bloqueia ou desbloqueia o canal atual',
    options: [{
        name: 'estado',
        type: ApplicationCommandOptionType.String,
        description: 'Bloquear ou Desbloquear',
        required: true,
        choices: [
            { name: '🔒 Bloquear', value: 'lock' },
            { name: '🔓 Desbloquear', value: 'unlock' }
        ]
    }],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return interaction.reply({ content: '❌ Sem permissão.', flags: [MessageFlags.Ephemeral] });
        }

        const state = interaction.options.getString('estado');
        const isLock = state === 'lock';

        await interaction.channel.permissionOverwrites.edit(interaction.guild.id, {
            SendMessages: !isLock
        });

        await interaction.reply({ 
            content: isLock ? '🔒 Este canal foi bloqueado para membros.' : '🔓 Este canal foi desbloqueado.' 
        });
    }
};
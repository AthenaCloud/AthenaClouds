const { ApplicationCommandOptionType, PermissionFlagsBits, MessageFlags } = require('discord.js');

module.exports = {
    name: 'unban',
    description: 'Desbane um utilizador pelo ID',
    options: [{
        name: 'id',
        type: ApplicationCommandOptionType.String,
        description: 'ID do utilizador a desbanir',
        required: true
    }],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return interaction.reply({ content: '❌ Sem permissão.', flags: [MessageFlags.Ephemeral] });
        }

        const userId = interaction.options.getString('id');

        try {
            await interaction.guild.members.unban(userId);
            await interaction.reply({ content: `✅ O utilizador com ID \`${userId}\` foi desbanido com sucesso.` });
        } catch (error) {
            await interaction.reply({ content: '❌ Não foi possível desbanir este ID. Verifica se o ID está correto ou se o utilizador está banido.', flags: [MessageFlags.Ephemeral] });
        }
    }
};
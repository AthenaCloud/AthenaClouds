const { ApplicationCommandOptionType, PermissionFlagsBits, EmbedBuilder, MessageFlags } = require('discord.js');

module.exports = {
    name: 'ban',
    description: 'Bane um usuário do servidor',
    options: [
        {
            name: 'usuario',
            type: ApplicationCommandOptionType.User,
            description: 'Usuário a ser banido',
            required: true
        },
        {
            name: 'motivo',
            type: ApplicationCommandOptionType.String,
            description: 'Motivo do banimento',
            required: false
        }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return interaction.reply({ content: '❌ Você não tem permissão para banir membros.', flags: [MessageFlags.Ephemeral] });
        }

        const target = interaction.options.getMember('usuario');
        const reason = interaction.options.getString('motivo') || 'Nenhum motivo informado.';

        if (!target) return interaction.reply({ content: '❌ Usuário não encontrado no servidor.', flags: [MessageFlags.Ephemeral] });
        if (!target.bannable) return interaction.reply({ content: '❌ Não consigo banir este usuário (Cargo superior ou igual ao meu).', flags: [MessageFlags.Ephemeral] });

        try {
            await target.ban({ reason: `Staff: ${interaction.user.tag} | Motivo: ${reason}` });

            const embed = new EmbedBuilder()
                .setTitle('🔨 Punição Aplicada')
                .setThumbnail(target.user.displayAvatarURL())
                .setColor('Red')
                .addFields(
                    { name: '👤 Usuário', value: `${target.user.tag}`, inline: true },
                    { name: '👮 Staff', value: `${interaction.user.tag}`, inline: true },
                    { name: '📝 Motivo', value: reason }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            await interaction.reply({ content: '❌ Ocorreu um erro ao tentar banir este usuário.', flags: [MessageFlags.Ephemeral] });
        }
    }
};
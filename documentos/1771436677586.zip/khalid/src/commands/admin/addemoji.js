const { ApplicationCommandOptionType, PermissionFlagsBits, MessageFlags, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'addemoji',
    description: 'Cria um emoji novo usando uma foto do seu dispositivo',
    options: [
        {
            name: 'arquivo',
            type: ApplicationCommandOptionType.Attachment,
            description: 'Arraste a foto do seu dispositivo aqui',
            required: true
        },
        {
            name: 'nome',
            type: ApplicationCommandOptionType.String,
            description: 'O nome que o emoji terá (sem espaços)',
            required: true
        }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageEmojisAndStickers)) {
            return interaction.reply({ 
                content: '❌ Você não tem permissão para gerenciar emojis.', 
                flags: [MessageFlags.Ephemeral] 
            });
        }

        const attachment = interaction.options.getAttachment('arquivo');
        const name = interaction.options.getString('nome');

        if (!attachment.contentType.startsWith('image')) {
            return interaction.reply({ content: '❌ Por favor, envie apenas arquivos de imagem (PNG, JPG, GIF).', flags: [MessageFlags.Ephemeral] });
        }

        await interaction.deferReply();

        try {
            const emoji = await interaction.guild.emojis.create({ 
                attachment: attachment.url, 
                name: name 
            });
            
            const embed = new EmbedBuilder()
                .setTitle('✅ Emoji Criado!')
                .setDescription(`O emoji **:${name}:** foi adicionado ao servidor com sucesso.`)
                .setThumbnail(attachment.url)
                .setColor('Green');

            await interaction.editReply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.editReply({ content: '❌ Erro ao criar emoji. Verifique se o nome não possui caracteres especiais ou se o servidor atingiu o limite de emojis.' });
        }
    }
};
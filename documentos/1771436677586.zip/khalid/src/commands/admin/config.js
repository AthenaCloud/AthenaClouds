const { 
    PermissionFlagsBits, 
    ActionRowBuilder, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'config',
    description: 'Abre o painel de configuração do bot',
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Comando restrito a Administradores.', flags: [MessageFlags.Ephemeral] });
        }

        const modal = new ModalBuilder()
            .setCustomId('config_modal')
            .setTitle('Configuração do Servidor');

        const logInput = new TextInputBuilder()
            .setCustomId('log_channel_id')
            .setLabel("ID do Canal de Logs")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Ex: 123456789012345678")
            .setRequired(true)
            .setMinLength(15);

        modal.addComponents(new ActionRowBuilder().addComponents(logInput));
        
        await interaction.showModal(modal);
    }
};
const { ApplicationCommandOptionType, PermissionFlagsBits, MessageFlags } = require('discord.js');

module.exports = {
    name: 'slowmode',
    description: 'Define o modo lento do canal atual',
    options: [{
        name: 'segundos',
        type: ApplicationCommandOptionType.Integer,
        description: 'Tempo em segundos (0 para desativar)',
        required: true
    }],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
            return interaction.reply({ content: '❌ Você precisa de permissão para gerenciar canais.', flags: [MessageFlags.Ephemeral] });
        }

        const seconds = interaction.options.getInteger('segundos');

        try {
            await interaction.channel.setRateLimitPerUser(seconds);
            const msg = seconds === 0 ? '🔓 O modo lento foi desativado.' : `⏳ Modo lento definido para **${seconds} segundos**.`;
            await interaction.reply({ content: msg });
        } catch (err) {
            await interaction.reply({ content: '❌ Não consegui alterar o modo lento deste canal.', flags: [MessageFlags.Ephemeral] });
        }
    }
};
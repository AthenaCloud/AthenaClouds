const { ApplicationCommandOptionType, PermissionFlagsBits, MessageFlags } = require('discord.js');
const db = require('../../database/db');

module.exports = {
    name: 'autorole',
    description: 'Configura o cargo automático para novos membros',
    options: [{
        name: 'cargo',
        type: ApplicationCommandOptionType.Role,
        description: 'Cargo a ser entregue',
        required: true
    }],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Sem permissão.', flags: [MessageFlags.Ephemeral] });
        }

        const role = interaction.options.getRole('cargo');

        if (role.managed) return interaction.reply({ content: '❌ Não posso usar cargos de integração (bots).', flags: [MessageFlags.Ephemeral] });

        db.prepare('INSERT INTO config (guild_id, autorole_id) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET autorole_id = ?')
          .run(interaction.guild.id, role.id, role.id);

        await interaction.reply({ content: `✅ O cargo **${role.name}** será entregue automaticamente a novos membros!` });
    }
};
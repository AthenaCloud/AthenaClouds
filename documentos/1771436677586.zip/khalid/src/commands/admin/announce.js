const { 
    ApplicationCommandOptionType, 
    PermissionFlagsBits, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle, 
    ActionRowBuilder 
} = require('discord.js');

module.exports = {
    name: 'announce',
    description: 'Envia um anúncio em Embed para o canal',
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) return;

        const modal = new ModalBuilder()
            .setCustomId('announce_modal')
            .setTitle('Novo Anúncio');

        const titleInput = new TextInputBuilder()
            .setCustomId('ann_title')
            .setLabel("Título do Anúncio")
            .setStyle(TextInputStyle.Short)
            .setRequired(true);

        const descInput = new TextInputBuilder()
            .setCustomId('ann_desc')
            .setLabel("Mensagem")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true);

        modal.addComponents(
            new ActionRowBuilder().addComponents(titleInput),
            new ActionRowBuilder().addComponents(descInput)
        );

        await interaction.showModal(modal);
    }
};
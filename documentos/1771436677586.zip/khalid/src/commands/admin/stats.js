const { EmbedBuilder, version } = require('discord.js');
const os = require('os');

module.exports = {
    name: 'stats',
    description: 'Mostra estatísticas técnicas do bot',
    run: async (client, interaction) => {
        const uptime = process.uptime();
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor(uptime / 3600) % 24;
        const minutes = Math.floor(uptime / 60) % 60;

        const memoryUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

        const embed = new EmbedBuilder()
            .setTitle('📊 Painel de Performance')
            .setColor('DarkButNotBlack')
            .addFields(
                { name: '🛰️ Servidores', value: `\`${client.guilds.cache.size}\``, inline: true },
                { name: '👥 Usuários', value: `\`${client.users.cache.size}\``, inline: true },
                { name: '⏳ Uptime', value: `\`${days}d ${hours}h ${minutes}m\``, inline: true },
                { name: '💾 Memória', value: `\`${memoryUsage} MB\``, inline: true },
                { name: '📚 Discord.js', value: `\`v${version}\``, inline: true },
                { name: '🟢 Node.js', value: `\`${process.version}\``, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};
const { 
    ApplicationCommandOptionType, 
    PermissionFlagsBits, 
    ActionRowBuilder, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle,
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'setrules',
    description: 'Envia as regras do servidor para um canal',
    options: [
        {
            name: 'canal',
            type: ApplicationCommandOptionType.Channel,
            description: 'Selecione o canal onde as regras serão enviadas',
            required: true
        }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ 
                content: '❌ Você precisa ser um administrador para usar este comando.', 
                flags: [MessageFlags.Ephemeral] 
            });
        }

        const channel = interaction.options.getChannel('canal');

        const modal = new ModalBuilder()
            .setCustomId(`rl_${channel.id}`) 
            .setTitle('📜 Configurar Regras');

        const textInput = new TextInputBuilder()
            .setCustomId('rules_content')
            .setLabel("Texto das Regras")
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder("Escreva aqui as regras...\nUse SHIFT + ENTER para pular linha.")
            .setRequired(true)
            .setMaxLength(4000);

        const row = new ActionRowBuilder().addComponents(textInput);
        modal.addComponents(row);

        try {
            await interaction.showModal(modal);
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: '❌ Erro ao abrir o formulário.', flags: [MessageFlags.Ephemeral] });
        }
    }
};
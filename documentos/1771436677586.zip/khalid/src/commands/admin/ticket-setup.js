const { 
    ApplicationCommandOptionType, PermissionFlagsBits, EmbedBuilder, 
    ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags, ChannelType 
} = require('discord.js');
const db = require('../../database/db');

module.exports = {
    name: 'ticket-setup',
    description: 'Configuração profissional do sistema de tickets',
    options: [
        {
            name: 'canal_painel',
            type: ApplicationCommandOptionType.Channel,
            description: 'Onde o painel será enviado',
            channel_types: [ChannelType.GuildText],
            required: true
        },
        {
            name: 'categoria',
            type: ApplicationCommandOptionType.Channel,
            description: 'Categoria onde os tickets serão criados',
            channel_types: [ChannelType.GuildCategory],
            required: true
        },
        {
            name: 'cargo_suporte',
            type: ApplicationCommandOptionType.Role,
            description: 'Cargo que terá acesso aos tickets',
            required: true
        }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Apenas administradores.', flags: [MessageFlags.Ephemeral] });
        }

        const painel = interaction.options.getChannel('canal_painel');
        const categoria = interaction.options.getChannel('categoria');
        const cargo = interaction.options.getRole('cargo_suporte');

        db.prepare(`
            INSERT INTO config (guild_id, ticket_category, ticket_roles) 
            VALUES (?, ?, ?) 
            ON CONFLICT(guild_id) DO UPDATE SET ticket_category = ?, ticket_roles = ?
        `).run(interaction.guild.id, categoria.id, cargo.id, categoria.id, cargo.id);

        const embed = new EmbedBuilder()
            .setTitle('🎫 Central de Atendimento')
            .setDescription('Clique no botão abaixo para abrir um ticket privado com a nossa equipe.')
            .setColor('Blue')
            .setFooter({ text: interaction.guild.name });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('open_ticket').setLabel('Abrir Ticket').setEmoji('📩').setStyle(ButtonStyle.Primary)
        );

        await painel.send({ embeds: [embed], components: [row] });
        await interaction.reply({ content: '✅ Sistema configurado com sucesso!', flags: [MessageFlags.Ephemeral] });
    }
};
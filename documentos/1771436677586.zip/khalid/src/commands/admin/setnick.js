const { ApplicationCommandOptionType, PermissionFlagsBits, MessageFlags } = require('discord.js');

module.exports = {
    name: 'setnick',
    description: 'Altera o apelido de um membro no servidor',
    options: [
        { name: 'usuario', type: ApplicationCommandOptionType.User, description: 'Membro', required: true },
        { name: 'apelido', type: ApplicationCommandOptionType.String, description: 'Novo nome (deixe vazio para resetar)', required: false }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageNicknames)) {
            return interaction.reply({ content: '❌ Sem permissão.', flags: [MessageFlags.Ephemeral] });
        }

        const target = interaction.options.getMember('usuario');
        const nick = interaction.options.getString('apelido');

        try {
            await target.setNickname(nick);
            await interaction.reply({ content: `✅ Apelido de ${target} atualizado com sucesso!` });
        } catch (err) {
            await interaction.reply({ content: '❌ Não consigo alterar o nome deste usuário.', flags: [MessageFlags.Ephemeral] });
        }
    }
};
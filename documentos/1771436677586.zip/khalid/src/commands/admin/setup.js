const { ApplicationCommandOptionType, PermissionFlagsBits } = require('discord.js');
const db = require('../../database/db');

module.exports = {
    name: 'setup',
    description: 'Configurações do servidor',
    options: [
        {
            name: 'logs',
            type: 7, 
            description: 'Canal de logs de moderação',
            required: false
        }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) return;

        const logChannel = interaction.options.getChannel('logs');

        if (logChannel) {
            db.prepare('INSERT OR REPLACE INTO config (guild_id, log_channel) VALUES (?, ?)')
              .run(interaction.guild.id, logChannel.id);
            
            interaction.reply(`✅ Canal de logs definido para ${logChannel}`);
        }
    }
};
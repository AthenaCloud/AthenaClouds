const { 
    ApplicationCommandOptionType, 
    PermissionFlagsBits, 
    ActionRowBuilder, 
    ModalBuilder, 
    TextInputBuilder, 
    TextInputStyle,
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'setwelcome',
    description: 'Configura a mensagem de boas-vindas via formulário',
    options: [
        {
            name: 'canal',
            type: ApplicationCommandOptionType.Channel,
            description: 'Canal onde as mensagens serão enviadas',
            required: true
        }
    ],
    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ Sem permissão.', flags: [MessageFlags.Ephemeral] });
        }

        const channel = interaction.options.getChannel('canal');

        const modal = new ModalBuilder()
            .setCustomId(`welcome_modal_${channel.id}`)
            .setTitle('📝 Configuração de Boas-Vindas');

        const textInput = new TextInputBuilder()
            .setCustomId('welcome_text')
            .setLabel("Mensagem (Pule linhas à vontade)")
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder("Olá {user}!\nBem-vindo ao servidor {guild}.\nLeia as regras!")
            .setRequired(true)
            .setMaxLength(1000);

        modal.addComponents(new ActionRowBuilder().addComponents(textInput));
        
        await interaction.showModal(modal);
    }
};
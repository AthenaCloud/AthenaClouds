const { ApplicationCommandOptionType, MessageFlags } = require('discord.js');
const db = require('../../database/db');
const crypto = require('crypto');
require('dotenv')

module.exports = {
    name: 'gerarkey',
    description: 'Gera uma chave de ativação de aluguel',
    options: [
        {
            name: 'tempo',
            type: ApplicationCommandOptionType.String,
            description: 'Ex: 1h, 30m, 7d',
            required: true
        }
    ],
    run: async (client, interaction) => {
        if (interaction.user.id !== process.env.OWNER_ID) {
            return interaction.reply({ content: '❌ Apenas o dono pode usar este comando.', flags: [MessageFlags.Ephemeral] });
        }

        const tempoInput = interaction.options.getString('tempo');
        const valor = parseInt(tempoInput);
        const unidade = tempoInput.slice(-1).toLowerCase();
        
        let ms = 0;
        if (unidade === 'm') ms = valor * 60000;
        else if (unidade === 'h') ms = valor * 3600000;
        else if (unidade === 'd') ms = valor * 86400000;
        else return interaction.reply({ content: '❌ Formato inválido! Use m, h ou d (ex: 7d).', flags: [MessageFlags.Ephemeral] });

        const key = `RENT-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
        
        db.prepare('INSERT INTO keys (key, duration_ms) VALUES (?, ?)').run(key, ms);

        await interaction.reply({
            content: `🔑 **Nova Key Gerada:** \`${key}\`\n⏳ **Duração:** ${tempoInput}\n\n**Como ativar?**\nNo servidor desejado, use o comando: \`/activerent key:${key}\``,
            flags: [MessageFlags.Ephemeral]
        });
    }
};
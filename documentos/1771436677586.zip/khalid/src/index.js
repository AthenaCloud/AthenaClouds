/**
 * ======================================
 *  Author : Tavares Coder
 *  Project: Khalid Bot
 *  Year   : 2026
 *  Version: 1.0.0
 * ======================================
 */


require('dotenv').config({ silent: true });
const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const db = require('./database/db');
const logger = require('./utils/logger');
const fs = require('fs');
const path = require('path');

process.noDeprecation = true;

console.clear();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

client.commands = new Collection();
const slashCommands = [];

// Carregando Comandos e preparando Deploy (não mexa se não souber oque está a fazer)
const commandFolders = fs.readdirSync(path.join(__dirname, 'commands'));
for (const folder of commandFolders) {
    const commandFiles = fs.readdirSync(path.join(__dirname, `commands/${folder}`)).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
        const command = require(`./commands/${folder}/${file}`);
        command.category = folder;
        client.commands.set(command.name, command);

        slashCommands.push({
            name: command.name,
            description: command.description,
            options: command.options || []
        });

        if (command.aliases && Array.isArray(command.aliases)) {
        for (const alias of command.aliases) {
            client.commands.set(alias, command);
            slashCommands.push({
                name: alias,
                description: command.description,
                options: command.options || []
            });
        }
    }
    }
}

require('./handlers/loader')(client);

client.once('clientReady', async () => {
    logger.success(`Logado como ${client.user.tag}`);

    const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
    try {
        logger.info('Iniciando atualização dos comandos globais (/)');
        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: slashCommands },
        );
        logger.success('Comandos registrados com sucesso!');
    } catch (error) {
        logger.error(`Erro no Auto-Deploy: ${error}`);
    }
});

client.login(process.env.TOKEN);